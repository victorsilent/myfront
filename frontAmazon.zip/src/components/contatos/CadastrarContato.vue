<template>
    <div class="box">
        <h1 class="title is-5">Informe os dados para cadastrar o contato</h1>
        <div class="columns">
          <form class="column is-half">
                <div class="field">
                  <label class="label">Nome</label>
                  <p class="control">
                    <input v-model="contato.nome" class="input" type="text" placeholder="Nome para o contato">
                  </p>
                </div>

                <div class="field">
                  <label class="label">Apelido</label>
                  <p class="control">
                    <input  v-model="contato.apelido" class="input" type="text" placeholder="Apelido para o contato">
                  </p>
                </div>

                <div class="field">
                  <label class="label">Email</label>
                  <p class="control">
                    <input v-model="contato.email" class="input" type="text" placeholder="Email do contato">
                  </p>
                </div>

                <div class="field">
                  <label class="label">Telefone para contato</label>
                  <p class="control">
                    <input v-model="contato.telefone" class="input" type="text" placeholder="Numero do telefone">
                  </p>
                </div>
                <div class="field">
                  <label class="label">Aniversário do contato</label>
                  <p class="control">
                    <datepicker placeholder="Selecione o aniversario" inputClass="input" format="dd-MM-yyyy" v-model="contato.aniversario"></datepicker>
                  </p>
                </div>

                <div class="field">
                  <label class="label">Foto</label>
                  <p class="control">
                    <input ref="avatar" type="file" placeholder="Nome para o contato">
                  </p>
                </div>

                <p class="control">
                  <button @click.prevent="pushData" type="submit" class="button is-primary">Cadastrar Contato</button>
                </p>
          </form>
        </div>
    </div>
</template>

<script>
import Datepicker from 'vuejs-datepicker'
import axios from "axios";
export default {
    data(){
        return{
            contato: {
              nome: "",
              apelido: "",
              email: "",
              telefone: "",
              aniversario: ""
            }
        }
    },
    components: {
      Datepicker
    },
    methods:{
      pushData: function(){
//         app.use(function(req, res, next) {
//   res.header("Access-Control-Allow-Origin", "*");
//   // Request methods you wish to allow
//   res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
//   // to the API (e.g. in case you use sessions)
//   res.setHeader('Access-Control-Allow-Credentials', true);
//   res.setHeader('Access-Control-Allow-Headers', 'Content-Type,X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5,  D$
//   next();
// });

        let formData = new FormData();
        //console.log(this.$refs.avatar.files[0])
        let datestr = (new Date(this.contato.aniversario)).toISOString();
        formData.append('avatar', this.$refs.avatar.files[0]);
        formData.append('nome',this.contato.nome);
        formData.append('email',this.contato.email);
        formData.append('apelido',this.contato.apelido);
        formData.append('telefone',this.contato.telefone);
        formData.append('aniversario',datestr);
        
        var vm = this;
        axios.defaults.headers.post['Content-Type'] = 'multipart/form-data';
        axios.post('http://ec2-52-38-170-214.us-west-2.compute.amazonaws.com:3000/contatos/',
          formData
        )
        .then(function (response) {
          vm.$router.push("/");
        })
        .catch(function (error) {
          console.log(error);
        });
      }
    }
}
</script>

<style lang="scss">
    
</style>


